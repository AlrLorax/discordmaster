import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import { z } from "zod";
import { storage } from "./storage";
import { botManager } from "./bot-manager";

// Discord API base URL
const DISCORD_API_BASE = "https://discord.com/api/v10";

// Multer configuration for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
});

// Store user tokens (in production, use secure storage)
const userTokens = new Map<string, string>();

// Validation schemas
const tokenSchema = z.object({
  token: z.string().min(1, "Token is required"),
});

const serverMessageSchema = z.object({
  serverId: z.string().min(1, "Server ID is required"),
});

const statusSchema = z.object({
  text: z.string().min(1, "Status text is required"),
  status: z.enum(["online", "idle", "dnd", "invisible"]),
  activityType: z.string(),
});

const usernameSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

const emailSchema = z.object({
  email: z.string().email("Valid email is required"),
  password: z.string().min(1, "Password is required"),
});

const passwordSchema = z.object({
  currentPassword: z.string().min(1, "Current password is required"),
  newPassword: z.string().min(1, "New password is required"),
});

const deleteAccountSchema = z.object({
  password: z.string().min(1, "Password is required"),
});

const voiceCallSchema = z.object({
  channelId: z.string().min(1, "Channel ID is required"),
  guildId: z.string().optional(),
  duration: z.number().positive().optional(), // in minutes
});

const botHostingSchema = z.object({
  botToken: z.string().min(1, "Bot token is required"),
  botName: z.string().min(1, "Bot name is required"),
  guildId: z.string().optional(),
});

const botFileUploadSchema = z.object({
  botName: z.string().min(1, "Bot name is required"),
  guildId: z.string().optional(),
});

const customCommandSchema = z.object({
  botId: z.number(),
  command: z.string().min(1, "Command is required"),
  response: z.string().min(1, "Response is required"),
});

// Helper function to make Discord API requests
async function makeDiscordRequest(endpoint: string, token: string, options: RequestInit = {}) {
  const response = await fetch(`${DISCORD_API_BASE}${endpoint}`, {
    ...options,
    headers: {
      "Authorization": token,
      "Content-Type": "application/json",
      ...options.headers,
    },
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Discord API Error: ${response.status} - ${errorText}`);
  }

  return response;
}

// Helper function to get user token from session
function getUserToken(req: any): string {
  const sessionId = (req as any).session?.id || (req as any).sessionID || "default";
  const token = userTokens.get(sessionId);
  if (!token) {
    throw new Error("No token found. Please validate your token first.");
  }
  return token;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Validate Discord token
  app.post("/api/discord/validate-token", async (req, res) => {
    try {
      const { token } = tokenSchema.parse(req.body);
      
      // Test token by fetching user info
      const response = await fetch(`${DISCORD_API_BASE}/users/@me`, {
        headers: {
          "Authorization": token,
        },
      });

      if (response.ok) {
        // Store token for this session
        const sessionId = (req as any).session?.id || "default";
        userTokens.set(sessionId, token);
        
        res.json({ valid: true, message: "Token validated successfully" });
      } else {
        res.json({ valid: false, message: "Invalid or expired token" });
      }
    } catch (error) {
      res.status(400).json({ valid: false, message: "Invalid token format" });
    }
  });

  // Get account information
  app.get("/api/discord/account", async (req, res) => {
    try {
      const token = getUserToken(req);
      const response = await makeDiscordRequest("/users/@me", token);
      const userData = await response.json();
      
      const accountInfo = {
        id: userData.id,
        username: `${userData.username}#${userData.discriminator}`,
        email: userData.email,
        avatar: userData.avatar ? 
          `https://cdn.discordapp.com/avatars/${userData.id}/${userData.avatar}.png` : 
          undefined,
        createdAt: new Date(Number((BigInt(userData.id) >> 22n) + 1420070400000n)).toLocaleDateString(),
      };
      
      res.json(accountInfo);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Delete all DMs
  app.post("/api/discord/delete-dms", async (req, res) => {
    try {
      const token = getUserToken(req);
      
      // Get all DM channels
      const channelsResponse = await makeDiscordRequest("/users/@me/channels", token);
      const channels = await channelsResponse.json();
      
      let deletedCount = 0;
      
      for (const channel of channels) {
        if (channel.type === 1) { // DM channel
          try {
            // Get messages in the channel
            const messagesResponse = await makeDiscordRequest(
              `/channels/${channel.id}/messages?limit=100`, 
              token
            );
            const messages = await messagesResponse.json();
            
            // Get user ID first
            const userResponse = await makeDiscordRequest("/users/@me", token);
            const userData = await userResponse.json();
            
            // Delete each message
            for (const message of messages) {
              if (message.author.id === userData.id) {
                await makeDiscordRequest(
                  `/channels/${channel.id}/messages/${message.id}`, 
                  token, 
                  { method: "DELETE" }
                );
                deletedCount++;
              }
            }
          } catch (error) {
            console.error(`Error deleting messages in channel ${channel.id}:`, error);
          }
        }
      }
      
      res.json({ message: `${deletedCount} DM messages deleted successfully` });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Delete messages in server
  app.post("/api/discord/delete-server-messages", async (req, res) => {
    try {
      const token = getUserToken(req);
      const { serverId } = serverMessageSchema.parse(req.body);
      
      // Get user ID
      const userResponse = await makeDiscordRequest("/users/@me", token);
      const userData = await userResponse.json();
      
      // Get server channels
      const channelsResponse = await makeDiscordRequest(`/guilds/${serverId}/channels`, token);
      const channels = await channelsResponse.json();
      
      let deletedCount = 0;
      
      for (const channel of channels) {
        if (channel.type === 0) { // Text channel
          try {
            // Get messages in the channel
            const messagesResponse = await makeDiscordRequest(
              `/channels/${channel.id}/messages?limit=100`, 
              token
            );
            const messages = await messagesResponse.json();
            
            // Delete user's messages
            for (const message of messages) {
              if (message.author.id === userData.id) {
                await makeDiscordRequest(
                  `/channels/${channel.id}/messages/${message.id}`, 
                  token, 
                  { method: "DELETE" }
                );
                deletedCount++;
              }
            }
          } catch (error) {
            console.error(`Error deleting messages in channel ${channel.id}:`, error);
          }
        }
      }
      
      res.json({ message: `${deletedCount} server messages deleted successfully` });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Remove all friends
  app.post("/api/discord/remove-friends", async (req, res) => {
    try {
      const token = getUserToken(req);
      
      // Get user's DM channels first
      const channelsResponse = await makeDiscordRequest("/users/@me/channels", token);
      const channels = await channelsResponse.json();
      
      let removedCount = 0;
      let closedDMs = 0;
      
      // Process DM channels to find potential friends
      for (const channel of channels) {
        if (channel.type === 1 && channel.recipients && channel.recipients.length > 0) { // DM channel
          const recipientId = channel.recipients[0].id;
          
          try {
            // Try to remove friend relationship
            await makeDiscordRequest(
              `/users/@me/relationships/${recipientId}`, 
              token, 
              { method: "DELETE" }
            );
            removedCount++;
            
            // Also close the DM channel
            await makeDiscordRequest(
              `/channels/${channel.id}`, 
              token, 
              { method: "DELETE" }
            );
            closedDMs++;
            
            // Add delay to avoid rate limiting
            await new Promise(resolve => setTimeout(resolve, 300));
          } catch (error) {
            // If friend removal fails, at least try to close the DM
            try {
              await makeDiscordRequest(
                `/channels/${channel.id}`, 
                token, 
                { method: "DELETE" }
              );
              closedDMs++;
            } catch (dmError) {
              console.log(`Could not close DM with ${recipientId}`);
            }
          }
        }
      }
      
      let message = "";
      if (removedCount > 0) {
        message += `${removedCount} amigos removidos com sucesso. `;
      }
      if (closedDMs > 0) {
        message += `${closedDMs} conversas DM fechadas. `;
      }
      
      if (removedCount === 0 && closedDMs === 0) {
        message = "Nenhum amigo ou conversa DM encontrada para remover.";
      }
      
      res.json({ message: message.trim() });
    } catch (error: any) {
      res.status(500).json({ 
        message: "Erro ao remover amigos. Verifique se o token está correto e se você tem permissão para executar essa ação."
      });
    }
  });

  // Check Nitro subscription
  app.post("/api/discord/check-nitro", async (req, res) => {
    try {
      const token = getUserToken(req);
      const response = await makeDiscordRequest("/users/@me", token);
      const userData = await response.json();
      
      const nitroTypes = {
        0: "None",
        1: "Nitro Classic",
        2: "Nitro",
        3: "Nitro Basic",
      };
      
      const nitroType = nitroTypes[userData.premium_type as keyof typeof nitroTypes] || "None";
      const hasNitro = userData.premium_type > 0;
      
      res.json({ 
        message: hasNitro ? 
          `Você possui ${nitroType}` : 
          "Você não possui Nitro",
        hasNitro,
        type: nitroType
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Clear notifications
  app.post("/api/discord/clear-notifications", async (req, res) => {
    try {
      const token = getUserToken(req);
      
      // Get all guilds
      const guildsResponse = await makeDiscordRequest("/users/@me/guilds", token);
      const guilds = await guildsResponse.json();
      
      let clearedCount = 0;
      
      for (const guild of guilds) {
        try {
          await makeDiscordRequest(
            `/guilds/${guild.id}/ack`, 
            token, 
            { method: "POST" }
          );
          clearedCount++;
        } catch (error) {
          console.error(`Error clearing notifications for guild ${guild.id}:`, error);
        }
      }
      
      res.json({ message: `Notifications cleared for ${clearedCount} servers` });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Update status
  app.post("/api/discord/update-status", async (req, res) => {
    try {
      const token = getUserToken(req);
      const { text, status, activityType } = statusSchema.parse(req.body);
      
      // Try to update user settings with the new status information
      const settingsPayload = {
        custom_status: {
          text: text.substring(0, 128), // Discord limits custom status to 128 characters
          emoji_id: null,
          emoji_name: null,
          expires_at: null
        },
        status: status
      };
      
      const response = await makeDiscordRequest("/users/@me/settings", token, {
        method: "PATCH",
        body: JSON.stringify(settingsPayload),
      });
      
      if (response.ok) {
        res.json({ message: "Status atualizado com sucesso" });
      } else {
        const errorData = await response.json();
        console.log("Status update failed:", errorData);
        res.status(500).json({ 
          message: "Não foi possível atualizar o status. O Discord pode ter limitado esta funcionalidade."
        });
      }
    } catch (error: any) {
      console.error("Status update error:", error);
      res.status(500).json({ 
        message: "Erro ao atualizar status. Esta funcionalidade pode estar limitada para self-bots."
      });
    }
  });

  // Change username
  app.post("/api/discord/change-username", async (req, res) => {
    try {
      const token = getUserToken(req);
      const { username, password } = usernameSchema.parse(req.body);
      
      await makeDiscordRequest("/users/@me", token, {
        method: "PATCH",
        body: JSON.stringify({ username, password }),
      });
      
      res.json({ message: "Username updated successfully" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Change email
  app.post("/api/discord/change-email", async (req, res) => {
    try {
      const token = getUserToken(req);
      const { email, password } = emailSchema.parse(req.body);
      
      await makeDiscordRequest("/users/@me", token, {
        method: "PATCH",
        body: JSON.stringify({ email, password }),
      });
      
      res.json({ message: "Email updated successfully" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Change password
  app.post("/api/discord/change-password", async (req, res) => {
    try {
      const token = getUserToken(req);
      const { currentPassword, newPassword } = passwordSchema.parse(req.body);
      
      await makeDiscordRequest("/users/@me", token, {
        method: "PATCH",
        body: JSON.stringify({ 
          password: currentPassword,
          new_password: newPassword 
        }),
      });
      
      res.json({ message: "Password updated successfully" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Update avatar
  app.post("/api/discord/update-avatar", upload.single("file"), async (req, res) => {
    try {
      const token = getUserToken(req);
      
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      
      // Convert file to base64
      const base64Avatar = `data:${req.file.mimetype};base64,${req.file.buffer.toString("base64")}`;
      
      await makeDiscordRequest("/users/@me", token, {
        method: "PATCH",
        body: JSON.stringify({ avatar: base64Avatar }),
      });
      
      res.json({ message: "Avatar updated successfully" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Update banner
  app.post("/api/discord/update-banner", upload.single("file"), async (req, res) => {
    try {
      const token = getUserToken(req);
      
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      
      // Convert file to base64
      const base64Banner = `data:${req.file.mimetype};base64,${req.file.buffer.toString("base64")}`;
      
      await makeDiscordRequest("/users/@me", token, {
        method: "PATCH",
        body: JSON.stringify({ banner: base64Banner }),
      });
      
      res.json({ message: "Banner updated successfully" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Leave all servers
  app.post("/api/discord/leave-servers", async (req, res) => {
    try {
      const token = getUserToken(req);
      
      // Get all guilds
      const guildsResponse = await makeDiscordRequest("/users/@me/guilds", token);
      const guilds = await guildsResponse.json();
      
      let leftCount = 0;
      
      for (const guild of guilds) {
        try {
          await makeDiscordRequest(
            `/users/@me/guilds/${guild.id}`, 
            token, 
            { method: "DELETE" }
          );
          leftCount++;
        } catch (error) {
          console.error(`Error leaving guild ${guild.id}:`, error);
        }
      }
      
      res.json({ message: `Left ${leftCount} servers successfully` });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Delete account
  app.post("/api/discord/delete-account", async (req, res) => {
    try {
      const token = getUserToken(req);
      const { password } = deleteAccountSchema.parse(req.body);
      
      await makeDiscordRequest("/users/@me", token, {
        method: "DELETE",
        body: JSON.stringify({ password }),
      });
      
      // Remove token from storage
      const sessionId = (req as any).session?.id || "default";
      userTokens.delete(sessionId);
      
      res.json({ message: "Account deletion request sent successfully" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Voice call endpoints
  app.post("/api/discord/join-voice", async (req, res) => {
    try {
      const token = getUserToken(req);
      const { channelId, guildId, duration } = voiceCallSchema.parse(req.body);
      const sessionId = (req as any).session?.id || "default";
      
      // Create voice call record
      await storage.createVoiceCall({
        session_id: sessionId,
        channel_id: channelId,
        guild_id: guildId,
        duration: duration,
        status: "active"
      });
      
      // Note: Actual voice connection requires WebSocket implementation
      // This is a placeholder for voice call functionality
      res.json({ 
        message: duration 
          ? `Entrando na call por ${duration} minutos...` 
          : "Entrando na call por tempo indeterminado...",
        channelId,
        duration: duration || null
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/discord/leave-voice", async (req, res) => {
    try {
      const sessionId = (req as any).session?.id || "default";
      
      // Get active voice calls and end them
      const activeCalls = await storage.getActiveVoiceCalls(sessionId);
      
      for (const call of activeCalls) {
        await storage.updateVoiceCall(call.id, {
          status: "ended",
          end_time: Date.now()
        });
      }
      
      res.json({ message: "Saiu de todas as calls ativas" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/discord/voice-status", async (req, res) => {
    try {
      const sessionId = (req as any).session?.id || "default";
      const activeCalls = await storage.getActiveVoiceCalls(sessionId);
      
      res.json({ 
        activeCalls: activeCalls.filter(call => call.status === "active"),
        count: activeCalls.length
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Bot hosting endpoints
  app.post("/api/discord/host-bot", async (req, res) => {
    try {
      const { botToken, botName, guildId } = botHostingSchema.parse(req.body);
      const sessionId = (req as any).session?.id || "default";
      
      // Test bot token validity
      const testResponse = await fetch(`${DISCORD_API_BASE}/users/@me`, {
        headers: { "Authorization": `Bot ${botToken}` }
      });
      
      if (!testResponse.ok) {
        return res.status(400).json({ message: "Token do bot inválido" });
      }
      
      const botData = await testResponse.json();
      
      // Create bot hosting record
      const botRecord = await storage.createBotHosting({
        session_id: sessionId,
        bot_token: botToken,
        bot_name: botName,
        guild_id: guildId,
        status: "starting"
      });
      
      // Start the bot using bot manager
      const started = await botManager.startBot(botRecord.id, botToken, botName);
      
      if (started) {
        // Update with start time
        await storage.updateBotHosting(botRecord.id, {
          start_time: Date.now(),
          status: "online"
        });
        
        res.json({ 
          message: `Bot ${botData.username} está online e sendo hospedado!`,
          botName: botData.username,
          id: botRecord.id
        });
      } else {
        await storage.updateBotHosting(botRecord.id, {
          status: "error"
        });
        
        res.status(500).json({ 
          message: "Falha ao iniciar o bot. Verifique o token." 
        });
      }
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/discord/stop-bot/:id", async (req, res) => {
    try {
      const botId = parseInt(req.params.id);
      
      // Stop the bot using bot manager
      await botManager.stopBot(botId);
      
      res.json({ message: "Bot parado com sucesso" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/discord/delete-bot/:id", async (req, res) => {
    try {
      const botId = parseInt(req.params.id);
      
      // Stop the bot first
      await botManager.stopBot(botId);
      
      // Then delete from database
      await storage.deleteBotHosting(botId);
      
      res.json({ message: "Bot removido com sucesso" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/discord/bots", async (req, res) => {
    try {
      const sessionId = (req as any).session?.id || "default";
      const bots = await storage.getBotHosting(sessionId);
      
      // Update with real-time status from bot manager
      const botsWithStatus = bots.map(bot => ({
        ...bot,
        status: botManager.getBotStatus(bot.id)
      }));
      
      res.json({ bots: botsWithStatus });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/discord/bot-status/:id", async (req, res) => {
    try {
      const botId = parseInt(req.params.id);
      const status = botManager.getBotStatus(botId);
      
      res.json({ id: botId, status });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Bot file upload and analysis
  app.post("/api/discord/upload-bot", upload.single("botFiles"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "Nenhum arquivo enviado" });
      }

      const { botName, guildId } = botFileUploadSchema.parse(req.body);
      const sessionId = (req as any).session?.id || "default";

      // Analyze uploaded file
      const analysis = await botManager.analyzeBotFiles(req.file.buffer, req.file.originalname);
      
      if (!analysis.success) {
        return res.status(400).json({ message: analysis.error });
      }

      // Create bot hosting record with analyzed data
      const botRecord = await storage.createBotHosting({
        session_id: sessionId,
        bot_token: analysis.token!,
        bot_name: botName,
        guild_id: guildId,
        status: "starting"
      });

      // Start the bot with extracted commands
      const started = await botManager.startBotWithFiles(
        botRecord.id, 
        analysis.token!, 
        botName, 
        analysis.commands,
        analysis.files
      );

      if (started) {
        await storage.updateBotHosting(botRecord.id, {
          start_time: Date.now(),
          status: "online"
        });

        res.json({
          message: `Bot ${botName} analisado e hospedado com sucesso!`,
          analysis: {
            mainFile: analysis.mainFile,
            commandsFound: analysis.commands.length,
            filesProcessed: analysis.files.length,
            token: analysis.token ? "✅ Token encontrado" : "❌ Token não encontrado"
          },
          botId: botRecord.id
        });
      } else {
        await storage.updateBotHosting(botRecord.id, { status: "error" });
        res.status(500).json({ message: "Falha ao iniciar o bot analisado" });
      }
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Custom commands endpoints
  app.post("/api/discord/custom-command", async (req, res) => {
    try {
      const { botId, command, response } = customCommandSchema.parse(req.body);
      
      await botManager.addCustomCommand(botId, command, response);
      
      res.json({ message: "Comando personalizado adicionado com sucesso!" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/discord/custom-commands/:botId", async (req, res) => {
    try {
      const botId = parseInt(req.params.botId);
      const commands = botManager.getCustomCommands(botId);
      
      res.json({ commands });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/discord/custom-command/:botId/:command", async (req, res) => {
    try {
      const botId = parseInt(req.params.botId);
      const command = req.params.command;
      
      await botManager.removeCustomCommand(botId, command);
      
      res.json({ message: "Comando personalizado removido!" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

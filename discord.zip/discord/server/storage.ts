import { users, voice_calls, bot_hosting, type User, type InsertUser, type VoiceCall, type InsertVoiceCall, type BotHosting, type InsertBotHosting } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createVoiceCall(call: InsertVoiceCall): Promise<VoiceCall>;
  updateVoiceCall(id: number, updates: Partial<VoiceCall>): Promise<VoiceCall | undefined>;
  getActiveVoiceCalls(sessionId: string): Promise<VoiceCall[]>;
  createBotHosting(bot: InsertBotHosting): Promise<BotHosting>;
  updateBotHosting(id: number, updates: Partial<BotHosting>): Promise<BotHosting | undefined>;
  getBotHosting(sessionId: string): Promise<BotHosting[]>;
  deleteBotHosting(id: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async createVoiceCall(call: InsertVoiceCall): Promise<VoiceCall> {
    const [voiceCall] = await db
      .insert(voice_calls)
      .values(call)
      .returning();
    return voiceCall;
  }

  async updateVoiceCall(id: number, updates: Partial<VoiceCall>): Promise<VoiceCall | undefined> {
    const [voiceCall] = await db
      .update(voice_calls)
      .set(updates)
      .where(eq(voice_calls.id, id))
      .returning();
    return voiceCall || undefined;
  }

  async getActiveVoiceCalls(sessionId: string): Promise<VoiceCall[]> {
    return await db
      .select()
      .from(voice_calls)
      .where(eq(voice_calls.session_id, sessionId));
  }

  async createBotHosting(bot: InsertBotHosting): Promise<BotHosting> {
    const [botHosting] = await db
      .insert(bot_hosting)
      .values(bot)
      .returning();
    return botHosting;
  }

  async updateBotHosting(id: number, updates: Partial<BotHosting>): Promise<BotHosting | undefined> {
    const [botHosting] = await db
      .update(bot_hosting)
      .set(updates)
      .where(eq(bot_hosting.id, id))
      .returning();
    return botHosting || undefined;
  }

  async getBotHosting(sessionId: string): Promise<BotHosting[]> {
    return await db
      .select()
      .from(bot_hosting)
      .where(eq(bot_hosting.session_id, sessionId));
  }

  async deleteBotHosting(id: number): Promise<void> {
    await db
      .delete(bot_hosting)
      .where(eq(bot_hosting.id, id));
  }
}

export const storage = new DatabaseStorage();

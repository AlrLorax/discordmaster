
import WebSocket from 'ws';
import { storage } from './storage';
import JSZip from 'jszip';

interface BotInstance {
  id: number;
  token: string;
  name: string;
  ws: WebSocket | null;
  heartbeatInterval: NodeJS.Timeout | null;
  sessionId: string;
  sequenceNumber: number | null;
}

class BotManager {
  private bots: Map<number, BotInstance> = new Map();
  private customCommands: Map<number, Map<string, string>> = new Map();
  private readonly DISCORD_GATEWAY_URL = 'wss://gateway.discord.gg/?v=10&encoding=json';

  async startBot(botId: number, token: string, name: string): Promise<boolean> {
    try {
      // Stop existing bot if running
      if (this.bots.has(botId)) {
        await this.stopBot(botId);
      }

      // Test token validity first
      const testResponse = await fetch('https://discord.com/api/v10/users/@me', {
        headers: { 'Authorization': `Bot ${token}` }
      });

      if (!testResponse.ok) {
        const errorData = await testResponse.text();
        console.error(`Token validation failed for ${name}:`, errorData);
        throw new Error(`Invalid bot token: ${testResponse.status}`);
      }

      const botData = await testResponse.json();
      console.log(`Token validated for bot: ${botData.username}#${botData.discriminator}`);

      const botInstance: BotInstance = {
        id: botId,
        token,
        name,
        ws: null,
        heartbeatInterval: null,
        sessionId: '',
        sequenceNumber: null
      };

      // Connect to Discord Gateway
      console.log(`Starting bot ${name}... Connecting to Discord Gateway`);
      const ws = new WebSocket(this.DISCORD_GATEWAY_URL);
      botInstance.ws = ws;

      // Add connection timeout
      const connectionTimeout = setTimeout(() => {
        if (ws.readyState !== WebSocket.OPEN) {
          console.error(`Bot ${name} connection timeout`);
          ws.close();
        }
      }, 30000); // 30 second timeout

      ws.on('open', () => {
        clearTimeout(connectionTimeout);
        console.log(`Bot ${name} connected to Discord Gateway successfully`);
      });

      ws.on('message', (data) => {
        const payload = JSON.parse(data.toString());
        this.handleGatewayMessage(botInstance, payload);
      });

      ws.on('close', (code, reason) => {
        console.log(`Bot ${name} disconnected with code ${code}:`, reason.toString());
        
        // Handle specific close codes
        if (code === 4014) {
          console.error(`Bot ${name} - Intent error: Enable MESSAGE_CONTENT_INTENT in Discord Developer Portal`);
        } else if (code === 4004) {
          console.error(`Bot ${name} - Authentication failed: Invalid token`);
        } else if (code === 4000) {
          console.error(`Bot ${name} - Unknown error`);
        } else if (code === 4001) {
          console.error(`Bot ${name} - Unknown opcode`);
        } else if (code === 4002) {
          console.error(`Bot ${name} - Decode error`);
        } else if (code === 4003) {
          console.error(`Bot ${name} - Not authenticated`);
        } else if (code === 4005) {
          console.error(`Bot ${name} - Already authenticated`);
        } else if (code === 4007 || code === 4008 || code === 4009) {
          console.error(`Bot ${name} - Rate limited or invalid session`);
        }
        
        this.handleDisconnect(botInstance);
      });

      ws.on('error', (error) => {
        console.error(`Bot ${name} error:`, error);
        this.handleDisconnect(botInstance);
      });

      this.bots.set(botId, botInstance);
      return true;
    } catch (error) {
      console.error(`Failed to start bot ${name}:`, error);
      return false;
    }
  }

  private handleGatewayMessage(bot: BotInstance, payload: any) {
    const { op, d, s, t } = payload;

    // Update sequence number
    if (s !== null) {
      bot.sequenceNumber = s;
    }

    switch (op) {
      case 10: // Hello
        this.handleHello(bot, d);
        break;
      case 11: // Heartbeat ACK
        // Heartbeat acknowledged
        break;
      case 0: // Dispatch
        this.handleDispatch(bot, t, d);
        break;
      case 9: // Invalid Session
        this.handleInvalidSession(bot);
        break;
      case 7: // Reconnect
        this.handleReconnect(bot);
        break;
    }
  }

  private handleHello(bot: BotInstance, data: any) {
    const { heartbeat_interval } = data;

    // Start heartbeat
    bot.heartbeatInterval = setInterval(() => {
      if (bot.ws && bot.ws.readyState === WebSocket.OPEN) {
        bot.ws.send(JSON.stringify({
          op: 1,
          d: bot.sequenceNumber
        }));
      }
    }, heartbeat_interval);

    // Send identify payload
    this.sendIdentify(bot);
  }

  private sendIdentify(bot: BotInstance) {
    if (!bot.ws || bot.ws.readyState !== WebSocket.OPEN) return;

    const identifyPayload = {
      op: 2,
      d: {
        token: bot.token,
        intents: 3276799, // GUILDS + GUILD_MESSAGES + MESSAGE_CONTENT
        properties: {
          os: 'linux',
          browser: 'replit-bot-host',
          device: 'replit-bot-host'
        }
      }
    };

    bot.ws.send(JSON.stringify(identifyPayload));
  }

  private handleDispatch(bot: BotInstance, eventType: string, data: any) {
    switch (eventType) {
      case 'READY':
        console.log(`Bot ${bot.name} is now online!`);
        bot.sessionId = data.session_id;
        this.updateBotStatus(bot.id, 'online');
        break;
      case 'RESUMED':
        console.log(`Bot ${bot.name} resumed session`);
        break;
      case 'MESSAGE_CREATE':
        this.handleMessage(bot, data);
        break;
    }
  }

  private async handleMessage(bot: BotInstance, message: any) {
    // Ignore messages from bots
    if (message.author.bot) return;
    
    const content = message.content.toLowerCase();
    
    // Built-in commands
    if (content === '!ping') {
      await this.sendMessage(bot, message.channel_id, 'Pong! 🏓');
      return;
    }
    
    if (content === '!help') {
      await this.sendMessage(bot, message.channel_id, 
        `**Comandos disponíveis:**\n` +
        `!ping - Teste de resposta\n` +
        `!help - Mostra esta mensagem\n` +
        `!info - Informações do bot\n` +
        `!time - Hora atual\n` +
        `!roll - Rola um dado (1-6)\n` +
        `!uptime - Tempo online do bot`);
      return;
    }

    if (content === '!info') {
      await this.sendMessage(bot, message.channel_id, 
        `**${bot.name}**\n` +
        `🤖 Bot hospedado no Replit\n` +
        `🟢 Status: Online\n` +
        `⚡ Pronto para servir!`);
      return;
    }

    if (content === '!time') {
      const now = new Date();
      await this.sendMessage(bot, message.channel_id, 
        `🕐 Horário atual: ${now.toLocaleString('pt-BR')}`);
      return;
    }

    if (content === '!roll') {
      const roll = Math.floor(Math.random() * 6) + 1;
      await this.sendMessage(bot, message.channel_id, 
        `🎲 Você tirou: **${roll}**`);
      return;
    }

    if (content === '!uptime') {
      const uptime = process.uptime();
      const hours = Math.floor(uptime / 3600);
      const minutes = Math.floor((uptime % 3600) / 60);
      await this.sendMessage(bot, message.channel_id, 
        `⏱️ Bot online há: ${hours}h ${minutes}m`);
      return;
    }

    // Custom responses
    if (content.includes('olá') || content.includes('oi')) {
      await this.sendMessage(bot, message.channel_id, 
        `Olá ${message.author.username}! 👋 Como posso ajudar?`);
      return;
    }

    if (content.includes('como vai') || content.includes('tudo bem')) {
      await this.sendMessage(bot, message.channel_id, 
        'Tudo ótimo! 😊 Pronto para ajudar!');
      return;
    }

    // Easter eggs
    if (content.includes('replit')) {
      await this.sendMessage(bot, message.channel_id, 
        'Replit é incrível! 🚀 Hospedando bots 24/7!');
      return;
    }

    // Check custom commands
    const customCommands = this.customCommands.get(bot.id);
    if (customCommands) {
      for (const [command, response] of customCommands.entries()) {
        if (content === `!${command.toLowerCase()}`) {
          await this.sendMessage(bot, message.channel_id, response);
          return;
        }
      }
    }
  }

  private async sendMessage(bot: BotInstance, channelId: string, content: string) {
    try {
      await fetch(`https://discord.com/api/v10/channels/${channelId}/messages`, {
        method: 'POST',
        headers: {
          'Authorization': `Bot ${bot.token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ content })
      });
    } catch (error) {
      console.error(`Failed to send message:`, error);
    }
  }

  private handleInvalidSession(bot: BotInstance) {
    console.log(`Bot ${bot.name} received invalid session, reconnecting...`);
    bot.sessionId = '';
    bot.sequenceNumber = null;
    setTimeout(() => {
      this.sendIdentify(bot);
    }, 5000);
  }

  private handleReconnect(bot: BotInstance) {
    console.log(`Bot ${bot.name} requested to reconnect`);
    this.reconnectBot(bot);
  }

  private reconnectBot(bot: BotInstance) {
    if (bot.ws) {
      bot.ws.close();
    }
    
    setTimeout(() => {
      this.startBot(bot.id, bot.token, bot.name);
    }, 5000);
  }

  private handleDisconnect(bot: BotInstance) {
    if (bot.heartbeatInterval) {
      clearInterval(bot.heartbeatInterval);
      bot.heartbeatInterval = null;
    }

    this.updateBotStatus(bot.id, 'offline');
    console.log(`Bot ${bot.name} disconnected, will retry in 5 seconds...`);

    // Auto-reconnect after 5 seconds
    setTimeout(() => {
      if (this.bots.has(bot.id)) {
        console.log(`Attempting to reconnect bot ${bot.name}...`);
        this.startBot(bot.id, bot.token, bot.name);
      }
    }, 5000);
  }

  private async updateBotStatus(botId: number, status: string) {
    try {
      await storage.updateBotHosting(botId, { status });
    } catch (error) {
      console.error(`Failed to update bot status:`, error);
    }
  }

  async stopBot(botId: number): Promise<void> {
    const bot = this.bots.get(botId);
    if (!bot) return;

    if (bot.heartbeatInterval) {
      clearInterval(bot.heartbeatInterval);
    }

    if (bot.ws) {
      bot.ws.close();
    }

    this.bots.delete(botId);
    await this.updateBotStatus(botId, 'offline');
    console.log(`Bot ${bot.name} stopped`);
  }

  async stopAllBots(): Promise<void> {
    const botIds = Array.from(this.bots.keys());
    for (const botId of botIds) {
      await this.stopBot(botId);
    }
  }

  getBotStatus(botId: number): string {
    const bot = this.bots.get(botId);
    if (!bot) return 'offline';
    
    return bot.ws && bot.ws.readyState === WebSocket.OPEN ? 'online' : 'offline';
  }

  getAllBotsStatus(): { id: number; name: string; status: string }[] {
    return Array.from(this.bots.values()).map(bot => ({
      id: bot.id,
      name: bot.name,
      status: this.getBotStatus(bot.id)
    }));
  }

  addCustomCommand(botId: number, command: string, response: string): void {
    if (!this.customCommands.has(botId)) {
      this.customCommands.set(botId, new Map());
    }
    
    const botCommands = this.customCommands.get(botId)!;
    botCommands.set(command.toLowerCase(), response);
    
    console.log(`Added custom command '${command}' to bot ${botId}`);
  }

  removeCustomCommand(botId: number, command: string): void {
    const botCommands = this.customCommands.get(botId);
    if (botCommands) {
      botCommands.delete(command.toLowerCase());
      console.log(`Removed custom command '${command}' from bot ${botId}`);
    }
  }

  getCustomCommands(botId: number): Array<{ command: string; response: string }> {
    const botCommands = this.customCommands.get(botId);
    if (!botCommands) return [];
    
    return Array.from(botCommands.entries()).map(([command, response]) => ({
      command,
      response
    }));
  }

  async analyzeBotFiles(fileBuffer: Buffer, filename: string): Promise<{
    success: boolean;
    error?: string;
    token?: string;
    mainFile?: string;
    commands: Array<{ command: string; response: string }>;
    files: Array<{ name: string; content: string }>;
  }> {
    try {
      let files: Array<{ name: string; content: string }> = [];

      // Handle different file types
      if (filename.endsWith('.zip')) {
        const zip = new JSZip();
        const zipContent = await zip.loadAsync(fileBuffer);
        
        for (const [relativePath, file] of Object.entries(zipContent.files)) {
          if (!file.dir && this.isSupportedFile(relativePath)) {
            const content = await file.async('text');
            files.push({ name: relativePath, content });
          }
        }
      } else if (this.isSupportedFile(filename)) {
        // Single file upload
        const content = fileBuffer.toString('utf-8');
        files.push({ name: filename, content });
      } else {
        return { success: false, error: "Formato de arquivo não suportado. Use .js, .py, .ts ou .zip" };
      }

      if (files.length === 0) {
        return { success: false, error: "Nenhum arquivo de bot encontrado" };
      }

      // Analyze files
      const analysis = this.analyzeCodeFiles(files);
      
      if (!analysis.token) {
        return { success: false, error: "Token do bot não encontrado nos arquivos" };
      }

      return {
        success: true,
        token: analysis.token,
        mainFile: analysis.mainFile,
        commands: analysis.commands,
        files
      };
    } catch (error) {
      console.error('Error analyzing bot files:', error);
      return { success: false, error: "Erro ao analisar arquivos do bot" };
    }
  }

  private isSupportedFile(filename: string): boolean {
    const supportedExtensions = ['.js', '.ts', '.py', '.json'];
    return supportedExtensions.some(ext => filename.toLowerCase().endsWith(ext));
  }

  private analyzeCodeFiles(files: Array<{ name: string; content: string }>): {
    token?: string;
    mainFile?: string;
    commands: Array<{ command: string; response: string }>;
  } {
    let token: string | undefined;
    let mainFile: string | undefined;
    const commands: Array<{ command: string; response: string }> = [];

    // Priority order for main files
    const mainFilePriorities = ['index.js', 'main.js', 'bot.js', 'app.js', 'index.ts', 'main.ts', 'bot.ts', 'main.py', 'bot.py'];

    for (const file of files) {
      const content = file.content;
      const fileName = file.name.toLowerCase();

      // Extract token
      if (!token) {
        token = this.extractToken(content);
      }

      // Identify main file
      if (!mainFile) {
        if (mainFilePriorities.includes(fileName) || 
            content.includes('client.login') || 
            content.includes('bot.run') ||
            content.includes('discord.Client') ||
            content.includes('commands.Bot')) {
          mainFile = file.name;
        }
      }

      // Extract commands
      const fileCommands = this.extractCommands(content, fileName);
      commands.push(...fileCommands);
    }

    // If no main file found, use first JS/TS/PY file
    if (!mainFile && files.length > 0) {
      const codeFile = files.find(f => 
        f.name.endsWith('.js') || f.name.endsWith('.ts') || f.name.endsWith('.py')
      );
      if (codeFile) mainFile = codeFile.name;
    }

    return { token, mainFile, commands };
  }

  private extractToken(content: string): string | undefined {
    // Common token patterns
    const tokenPatterns = [
      /(?:client\.login|bot\.run)\s*\(\s*['"`]([^'"`]+)['"`]\s*\)/i,
      /(?:token\s*[:=]\s*['"`]([^'"`]+)['"`])/i,
      /(?:TOKEN\s*[:=]\s*['"`]([^'"`]+)['"`])/i,
      /(?:process\.env\.(?:BOT_)?TOKEN\s*\|\|\s*['"`]([^'"`]+)['"`])/i,
      /['"`]([A-Za-z0-9_-]{70,})['"`]/g, // Discord token format
    ];

    for (const pattern of tokenPatterns) {
      const match = content.match(pattern);
      if (match && match[1] && match[1].length > 50) {
        return match[1];
      }
    }

    return undefined;
  }

  private extractCommands(content: string, fileName: string): Array<{ command: string; response: string }> {
    const commands: Array<{ command: string; response: string }> = [];

    if (fileName.endsWith('.js') || fileName.endsWith('.ts')) {
      // JavaScript/TypeScript command patterns
      this.extractJSCommands(content, commands);
    } else if (fileName.endsWith('.py')) {
      // Python command patterns
      this.extractPythonCommands(content, commands);
    }

    return commands;
  }

  private extractJSCommands(content: string, commands: Array<{ command: string; response: string }>) {
    // Discord.js command patterns
    const patterns = [
      // if (message.content === '!command')
      /if\s*\(\s*message\.content(?:\.toLowerCase\(\))?\s*===?\s*['"`]!([^'"`]+)['"`]\s*\)[\s\S]*?(?:message\.reply|message\.channel\.send|message\.send)\s*\(\s*['"`]([^'"`]+)['"`]/gi,
      
      // switch case patterns
      /case\s*['"`]!([^'"`]+)['"`]\s*:[\s\S]*?(?:message\.reply|message\.channel\.send|message\.send)\s*\(\s*['"`]([^'"`]+)['"`]/gi,
      
      // command handler patterns
      /['"`]([^'"`]+)['"`]\s*:\s*(?:function|\(\s*\)|=>\s*{)[\s\S]*?(?:return\s*)?['"`]([^'"`]+)['"`]/gi,
    ];

    for (const pattern of patterns) {
      let match;
      while ((match = pattern.exec(content)) !== null) {
        const command = match[1].toLowerCase();
        const response = match[2];
        if (command && response && !commands.some(c => c.command === command)) {
          commands.push({ command, response });
        }
      }
    }
  }

  private extractPythonCommands(content: string, commands: Array<{ command: string; response: string }>) {
    // Python discord.py command patterns
    const patterns = [
      // if message.content == '!command':
      /if\s+message\.content(?:\.lower\(\))?\s*==\s*['"`]!([^'"`]+)['"`]\s*:[\s\S]*?(?:await\s+)?message\.channel\.send\s*\(\s*['"`]([^'"`]+)['"`]/gi,
      
      // @bot.command() decorator
      /@bot\.command\(\s*name\s*=\s*['"`]([^'"`]+)['"`][\s\S]*?async\s+def[\s\S]*?(?:await\s+)?ctx\.send\s*\(\s*['"`]([^'"`]+)['"`]/gi,
      
      // @client.command() decorator
      /@client\.command\(\s*name\s*=\s*['"`]([^'"`]+)['"`][\s\S]*?async\s+def[\s\S]*?(?:await\s+)?ctx\.send\s*\(\s*['"`]([^'"`]+)['"`]/gi,
    ];

    for (const pattern of patterns) {
      let match;
      while ((match = pattern.exec(content)) !== null) {
        const command = match[1].toLowerCase();
        const response = match[2];
        if (command && response && !commands.some(c => c.command === command)) {
          commands.push({ command, response });
        }
      }
    }
  }

  async startBotWithFiles(
    botId: number, 
    token: string, 
    name: string, 
    extractedCommands: Array<{ command: string; response: string }>,
    files: Array<{ name: string; content: string }>
  ): Promise<boolean> {
    // Add extracted commands to bot
    this.customCommands.set(botId, new Map());
    const botCommands = this.customCommands.get(botId)!;
    
    for (const cmd of extractedCommands) {
      botCommands.set(cmd.command.toLowerCase(), cmd.response);
    }

    console.log(`Bot ${name} carregado com ${extractedCommands.length} comandos dos arquivos:`, 
      extractedCommands.map(c => `!${c.command}`).join(', '));

    // Start the bot normally
    return this.startBot(botId, token, name);
  }
}

export const botManager = new BotManager();

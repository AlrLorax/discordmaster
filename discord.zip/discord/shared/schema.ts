import { sqliteTable, text, integer, blob } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { sql } from "drizzle-orm";

export const users = sqliteTable("users", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const discord_sessions = sqliteTable("discord_sessions", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  session_id: text("session_id").notNull().unique(),
  discord_token: text("discord_token").notNull(),
  user_id: text("user_id").notNull(),
  username: text("username").notNull(),
  email: text("email"),
  avatar: text("avatar"),
  created_at: integer("created_at").notNull().default(sql`(unixepoch())`),
  updated_at: integer("updated_at").notNull().default(sql`(unixepoch())`),
});

export const voice_calls = sqliteTable("voice_calls", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  session_id: text("session_id").notNull(),
  channel_id: text("channel_id").notNull(),
  guild_id: text("guild_id"),
  duration: integer("duration"), // in minutes, null for indefinite
  start_time: integer("start_time").notNull().default(sql`(unixepoch())`),
  end_time: integer("end_time"),
  status: text("status").notNull().default("active"), // active, ended, failed
  created_at: integer("created_at").notNull().default(sql`(unixepoch())`),
});

export const bot_hosting = sqliteTable("bot_hosting", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  session_id: text("session_id").notNull(),
  bot_token: text("bot_token").notNull(),
  bot_name: text("bot_name").notNull(),
  status: text("status").notNull().default("offline"), // online, offline, error
  guild_id: text("guild_id"),
  start_time: integer("start_time"),
  created_at: integer("created_at").notNull().default(sql`(unixepoch())`),
  updated_at: integer("updated_at").notNull().default(sql`(unixepoch())`),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertDiscordSessionSchema = createInsertSchema(discord_sessions).omit({
  id: true,
  created_at: true,
  updated_at: true,
});

export const insertVoiceCallSchema = createInsertSchema(voice_calls).omit({
  id: true,
  start_time: true,
  end_time: true,
  created_at: true,
});

export const insertBotHostingSchema = createInsertSchema(bot_hosting).omit({
  id: true,
  start_time: true,
  created_at: true,
  updated_at: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertDiscordSession = z.infer<typeof insertDiscordSessionSchema>;
export type DiscordSession = typeof discord_sessions.$inferSelect;
export type InsertVoiceCall = z.infer<typeof insertVoiceCallSchema>;
export type VoiceCall = typeof voice_calls.$inferSelect;
export type InsertBotHosting = z.infer<typeof insertBotHostingSchema>;
export type BotHosting = typeof bot_hosting.$inferSelect;
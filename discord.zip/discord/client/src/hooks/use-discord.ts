import { useState, useCallback } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface AccountInfo {
  id: string;
  username: string;
  email: string;
  avatar?: string;
  createdAt: string;
}

interface NitroInfo {
  hasNitro: boolean;
  type?: string;
  expiresAt?: string;
}

export function useDiscord() {
  const [tokenStatus, setTokenStatus] = useState<"valid" | "invalid" | null>(null);
  const [isValidating, setIsValidating] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get account info
  const { data: accountInfo } = useQuery<AccountInfo>({
    queryKey: ["/api/discord/account"],
    enabled: tokenStatus === "valid",
  });

  // Token validation
  const validateToken = useCallback(async (token: string) => {
    setIsValidating(true);
    try {
      const response = await apiRequest("POST", "/api/discord/validate-token", { token });
      const result = await response.json();
      
      if (result.valid) {
        setTokenStatus("valid");
        toast({
          title: "Sucesso",
          description: "Token validado com sucesso!",
        });
        queryClient.invalidateQueries({ queryKey: ["/api/discord/account"] });
      } else {
        setTokenStatus("invalid");
        toast({
          title: "Erro",
          description: "Token inválido ou expirado",
          variant: "destructive",
        });
      }
    } catch (error) {
      setTokenStatus("invalid");
      toast({
        title: "Erro",
        description: "Erro ao validar token",
        variant: "destructive",
      });
    } finally {
      setIsValidating(false);
    }
  }, [toast, queryClient]);

  // Discord operations
  const discordMutation = useMutation({
    mutationFn: async ({ endpoint, data }: { endpoint: string; data?: any }) => {
      const response = await apiRequest("POST", `/api/discord/${endpoint}`, data);
      return response.json();
    },
    onSuccess: (data, variables) => {
      toast({
        title: "Sucesso",
        description: data.message || "Operação realizada com sucesso!",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erro",
        description: error.message || "Erro ao realizar operação",
        variant: "destructive",
      });
    },
  });

  const uploadMutation = useMutation({
    mutationFn: async ({ endpoint, file }: { endpoint: string; file: File }) => {
      const formData = new FormData();
      formData.append("file", file);
      
      const response = await fetch(`/api/discord/${endpoint}`, {
        method: "POST",
        body: formData,
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error((await response.text()) || response.statusText);
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Sucesso",
        description: data.message || "Upload realizado com sucesso!",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erro",
        description: error.message || "Erro ao fazer upload",
        variant: "destructive",
      });
    },
  });

  // Discord API functions
  const deleteDMs = () => discordMutation.mutate({ endpoint: "delete-dms" });
  const deleteServerMessages = (serverId: string) => 
    discordMutation.mutate({ endpoint: "delete-server-messages", data: { serverId } });
  const removeAllFriends = () => discordMutation.mutate({ endpoint: "remove-friends" });
  const clearNotifications = () => discordMutation.mutate({ endpoint: "clear-notifications" });
  const leaveAllServers = () => discordMutation.mutate({ endpoint: "leave-servers" });

  const checkNitro = () => {
    discordMutation.mutate({ endpoint: "check-nitro" });
  };

  const getAccountInfo = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/discord/account"] });
    toast({
      title: "Informações atualizadas",
      description: "Dados da conta foram atualizados",
    });
  };

  const updateStatus = (text: string, status: string, activityType: string) => {
    discordMutation.mutate({ 
      endpoint: "update-status", 
      data: { text, status, activityType } 
    });
  };

  const changeUsername = (username: string, password: string) => {
    discordMutation.mutate({ 
      endpoint: "change-username", 
      data: { username, password } 
    });
  };

  const changeEmail = (email: string, password: string) => {
    discordMutation.mutate({ 
      endpoint: "change-email", 
      data: { email, password } 
    });
  };

  const changePassword = (currentPassword: string, newPassword: string) => {
    discordMutation.mutate({ 
      endpoint: "change-password", 
      data: { currentPassword, newPassword } 
    });
  };

  const updateAvatar = (file: File) => {
    uploadMutation.mutate({ endpoint: "update-avatar", file });
  };

  const updateBanner = (file: File) => {
    uploadMutation.mutate({ endpoint: "update-banner", file });
  };

  const deleteAccount = (password: string) => {
    discordMutation.mutate({ 
      endpoint: "delete-account", 
      data: { password } 
    });
  };

  // Voice call functions
  const joinVoice = (channelId: string, guildId?: string, duration?: number) => {
    discordMutation.mutate({ 
      endpoint: "join-voice", 
      data: { channelId, guildId, duration } 
    });
  };

  const leaveVoice = () => {
    discordMutation.mutate({ 
      endpoint: "leave-voice", 
      data: {} 
    });
  };

  // Bot hosting functions
  const hostBot = (botToken: string, botName: string, guildId?: string) => {
    discordMutation.mutate({ 
      endpoint: "host-bot", 
      data: { botToken, botName, guildId } 
    });
  };

  const stopBot = (botId: number) => {
    discordMutation.mutate({ 
      endpoint: `stop-bot/${botId}`, 
      data: {} 
    });
  };

  const deleteBot = (botId: number) => {
    discordMutation.mutate({ 
      endpoint: `delete-bot/${botId}`, 
      data: {},
      method: "DELETE" 
    });
  };

  return {
    tokenStatus,
    isValidating,
    isLoading: discordMutation.isPending || uploadMutation.isPending,
    accountInfo,
    validateToken,
    deleteDMs,
    deleteServerMessages,
    removeAllFriends,
    checkNitro,
    getAccountInfo,
    clearNotifications,
    updateStatus,
    changeUsername,
    changeEmail,
    changePassword,
    updateAvatar,
    updateBanner,
    leaveAllServers,
    deleteAccount,
    joinVoice,
    leaveVoice,
    hostBot,
    stopBot,
    deleteBot,
  };
}

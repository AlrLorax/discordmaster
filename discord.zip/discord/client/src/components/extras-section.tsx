import { useState } from "react";
import { motion } from "framer-motion";
import { Upload, LogOut, Trash2, AlertTriangle, Phone, PhoneOff, Bot, Play, Square, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { useDiscord } from "@/hooks/use-discord";

export default function ExtrasSection() {
  const [bannerFile, setBannerFile] = useState<File | null>(null);
  const [deletePassword, setDeletePassword] = useState("");
  const [channelId, setChannelId] = useState("");
  const [guildId, setGuildId] = useState("");
  const [duration, setDuration] = useState("");
  const [botToken, setBotToken] = useState("");
  const [botName, setBotName] = useState("");
  const [botGuildId, setBotGuildId] = useState("");
  const [botFiles, setBotFiles] = useState<File | null>(null); // Added botFiles state
  const [uploadBotName, setUploadBotName] = useState(""); // Added uploadBotName state
  const [uploadGuildId, setUploadGuildId] = useState(""); // Added uploadGuildId state

  const { toast } = useToast();
  const { 
    updateBanner, 
    leaveAllServers, 
    deleteAccount, 
    joinVoice, 
    leaveVoice, 
    hostBot, 
    stopBot, 
    deleteBot,
    isLoading 
  } = useDiscord();

  const handleUpdateBanner = () => {
    if (!bannerFile) {
      toast({
        title: "Erro",
        description: "Por favor, selecione uma imagem",
        variant: "destructive",
      });
      return;
    }
    updateBanner(bannerFile);
  };

  const handleLeaveAllServers = () => {
    if (confirm("Tem certeza que deseja sair de todos os servidores? Esta ação não pode ser desfeita.")) {
      leaveAllServers();
    }
  };

  const handleDeleteAccount = () => {
    if (!deletePassword.trim()) {
      toast({
        title: "Erro",
        description: "Por favor, digite sua senha para confirmar",
        variant: "destructive",
      });
      return;
    }

    if (confirm("⚠️ ATENÇÃO: Esta ação irá excluir permanentemente sua conta Discord. Esta ação é IRREVERSÍVEL. Tem certeza absoluta?")) {
      deleteAccount(deletePassword);
    }
  };

  const handleBannerFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setBannerFile(file);
    }
  };

  const handleJoinVoice = () => {
    if (!channelId.trim()) {
      toast({
        title: "Erro",
        description: "Por favor, insira o ID do canal",
        variant: "destructive",
      });
      return;
    }

    const durationNum = duration ? parseInt(duration) : undefined;
    joinVoice(channelId, guildId || undefined, durationNum);
  };

  const handleHostBot = () => {
    if (!botToken.trim() || !botName.trim()) {
      toast({
        title: "Erro",
        description: "Por favor, insira o token e nome do bot",
        variant: "destructive",
      });
      return;
    }

    hostBot(botToken, botName, botGuildId || undefined);
  };

  const handleUploadBot = async () => {
    if (!botFiles || !uploadBotName) {
      toast({
        title: "Erro",
        description: "Por favor, selecione os arquivos do bot e defina um nome",
        variant: "destructive",
      });
      return;
    }

    try {
      const formData = new FormData();
      formData.append('botFiles', botFiles);
      formData.append('botName', uploadBotName);
      if (uploadGuildId) formData.append('guildId', uploadGuildId);

      const response = await fetch('/api/discord/upload-bot', {
        method: 'POST',
        body: formData,
      });

      const data = await response.json();

      if (response.ok) {
        toast({
          title: "Sucesso!",
          description: data.message,
        });

        // Show analysis results
        toast({
          title: "Análise do Bot",
          description: `
            📁 Arquivo principal: ${data.analysis.mainFile}
            🤖 Comandos encontrados: ${data.analysis.commandsFound}
            📄 Arquivos processados: ${data.analysis.filesProcessed}
            🔑 ${data.analysis.token}
          `,
        });

        setBotFiles(null);
        setUploadBotName("");
        setUploadGuildId("");
      } else {
        toast({
          title: "Erro",
          description: data.message,
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Falha ao fazer upload do bot",
        variant: "destructive",
      });
    }
  };

  const handleBotFilesChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setBotFiles(file);
    }
  };

  return (
    <section className="max-w-6xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold text-white mb-2">🧪 Funções Extras</h1>
        <p className="text-gray-400">Ferramentas avançadas e opções especiais</p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Banner Upload (Nitro) */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <Card className="bg-[var(--dark-card)] border-[var(--dark-border)]">
            <CardHeader>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
                  <Upload className="w-5 h-5 text-white" />
                </div>
                <CardTitle className="text-white">Banner (Nitro)</CardTitle>
              </div>
              <CardDescription className="text-gray-400">
                Altere o banner do seu perfil (requer Nitro)
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="border-2 border-dashed border-[var(--dark-border)] rounded-lg p-6 text-center">
                <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                <p className="text-gray-400 text-sm mb-2">
                  {bannerFile ? bannerFile.name : "Banner 600x240px"}
                </p>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleBannerFileChange}
                  className="hidden"
                  id="banner-upload"
                />
                <Label
                  htmlFor="banner-upload"
                  className="cursor-pointer text-[var(--primary)] hover:text-[var(--primary)]/80"
                >
                  Selecionar Arquivo
                </Label>
              </div>
              <Button
                onClick={handleUpdateBanner}
                disabled={isLoading}
                className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white"
              >
                Atualizar Banner
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        {/* Leave All Servers */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <Card className="bg-[var(--dark-card)] border-[var(--dark-border)]">
            <CardHeader>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-orange-500/20 rounded-lg flex items-center justify-center">
                  <LogOut className="w-5 h-5 text-orange-400" />
                </div>
                <CardTitle className="text-white">Sair de Servidores</CardTitle>
              </div>
              <CardDescription className="text-gray-400">
                Remove sua conta de todos os servidores
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Alert className="mb-4 bg-orange-900/30 border-orange-600">
                <AlertTriangle className="h-4 w-4 text-orange-500" />
                <AlertDescription className="text-orange-200">
                  Esta ação irá remover você de todos os servidores Discord. Você precisará ser convidado novamente para voltar.
                </AlertDescription>
              </Alert>
              <Button
                onClick={handleLeaveAllServers}
                disabled={isLoading}
                className="w-full bg-orange-500 hover:bg-orange-600 text-white"
              >
                Sair de todos os servidores
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        {/* Voice Call Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          <Card className="bg-[var(--dark-card)] border-[var(--dark-border)]">
            <CardHeader>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center">
                  <Phone className="w-5 h-5 text-blue-400" />
                </div>
                <CardTitle className="text-white">Entrar em Call</CardTitle>
              </div>
              <CardDescription className="text-gray-400">
                Entre em um canal de voz por tempo determinado ou indeterminado
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div>
                  <Label htmlFor="channel-id" className="text-gray-300">
                    ID do Canal de Voz
                  </Label>
                  <Input
                    id="channel-id"
                    value={channelId}
                    onChange={(e) => setChannelId(e.target.value)}
                    placeholder="Ex: 123456789012345678"
                    className="bg-[var(--dark)] border-[var(--dark-border)] text-white placeholder-gray-500"
                  />
                </div>
                <div>
                  <Label htmlFor="guild-id" className="text-gray-300">
                    ID do Servidor (Opcional)
                  </Label>
                  <Input
                    id="guild-id"
                    value={guildId}
                    onChange={(e) => setGuildId(e.target.value)}
                    placeholder="Ex: 123456789012345678"
                    className="bg-[var(--dark)] border-[var(--dark-border)] text-white placeholder-gray-500"
                  />
                </div>
                <div>
                  <Label htmlFor="duration" className="text-gray-300">
                    Duração em Minutos (Vazio = Indeterminado)
                  </Label>
                  <Input
                    id="duration"
                    type="number"
                    value={duration}
                    onChange={(e) => setDuration(e.target.value)}
                    placeholder="Ex: 30"
                    className="bg-[var(--dark)] border-[var(--dark-border)] text-white placeholder-gray-500"
                  />
                </div>
                <div className="flex space-x-2">
                  <Button
                    onClick={handleJoinVoice}
                    disabled={isLoading}
                    className="flex-1 bg-blue-500 hover:bg-blue-600 text-white"
                  >
                    <Phone className="w-4 h-4 mr-2" />
                    Entrar na Call
                  </Button>
                  <Button
                    onClick={() => leaveVoice()}
                    disabled={isLoading}
                    variant="outline"
                    className="flex-1 border-red-500 text-red-400 hover:bg-red-500/10"
                  >
                    <PhoneOff className="w-4 h-4 mr-2" />
                    Sair da Call
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Bot Hosting Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
        >
          <Card className="bg-[var(--dark-card)] border-[var(--dark-border)]">
            <CardHeader>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center">
                  <Bot className="w-5 h-5 text-green-400" />
                </div>
                <CardTitle className="text-white">Hospedar Bot</CardTitle>
              </div>
              <CardDescription className="text-gray-400">
                Mantenha seu bot Discord online automaticamente
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div>
                  <Label htmlFor="bot-token" className="text-gray-300">
                    Token do Bot
                  </Label>
                  <Input
                    id="bot-token"
                    type="password"
                    value={botToken}
                    onChange={(e) => setBotToken(e.target.value)}
                    placeholder="Token do bot Discord"
                    className="bg-[var(--dark)] border-[var(--dark-border)] text-white placeholder-gray-500"
                  />
                </div>
                <div>
                  <Label htmlFor="bot-name" className="text-gray-300">
                    Nome do Bot
                  </Label>
                  <Input
                    id="bot-name"
                    value={botName}
                    onChange={(e) => setBotName(e.target.value)}
                    placeholder="Ex: Meu Bot"
                    className="bg-[var(--dark)] border-[var(--dark-border)] text-white placeholder-gray-500"
                  />
                </div>
                <div>
                  <Label htmlFor="bot-guild-id" className="text-gray-300">
                    ID do Servidor (Opcional)
                  </Label>
                  <Input
                    id="bot-guild-id"
                    value={botGuildId}
                    onChange={(e) => setBotGuildId(e.target.value)}
                    placeholder="Ex: 123456789012345678"
                    className="bg-[var(--dark)] border-[var(--dark-border)] text-white placeholder-gray-500"
                  />
                </div>
                <Button
                  onClick={handleHostBot}
                  disabled={isLoading}
                  className="w-full bg-green-500 hover:bg-green-600 text-white"
                >
                  <Bot className="w-4 h-4 mr-2" />
                  Hospedar Bot
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>

         {/* Upload Bot Section */}
         <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
        >
          <Card className="bg-[var(--dark-card)] border-[var(--dark-border)]">
            <CardHeader>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center">
                  <Bot className="w-5 h-5 text-green-400" />
                </div>
                <CardTitle className="text-white">Upload Bot</CardTitle>
              </div>
              <CardDescription className="text-gray-400">
                Faça upload dos arquivos do seu bot para hospedagem
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div>
                  <Label htmlFor="bot-files" className="text-gray-300">
                    Arquivos do Bot (zip, pasta)
                  </Label>
                  <Input
                    id="bot-files"
                    type="file"
                    onChange={handleBotFilesChange}
                    className="bg-[var(--dark)] border-[var(--dark-border)] text-white placeholder-gray-500"
                  />
                </div>
                <div>
                  <Label htmlFor="upload-bot-name" className="text-gray-300">
                    Nome do Bot
                  </Label>
                  <Input
                    id="upload-bot-name"
                    value={uploadBotName}
                    onChange={(e) => setUploadBotName(e.target.value)}
                    placeholder="Ex: Meu Bot"
                    className="bg-[var(--dark)] border-[var(--dark-border)] text-white placeholder-gray-500"
                  />
                </div>
                <div>
                  <Label htmlFor="upload-guild-id" className="text-gray-300">
                    ID do Servidor (Opcional)
                  </Label>
                  <Input
                    id="upload-guild-id"
                    value={uploadGuildId}
                    onChange={(e) => setUploadGuildId(e.target.value)}
                    placeholder="Ex: 123456789012345678"
                    className="bg-[var(--dark)] border-[var(--dark-border)] text-white placeholder-gray-500"
                  />
                </div>
                <Button
                  onClick={handleUploadBot}
                  disabled={isLoading}
                  className="w-full bg-green-500 hover:bg-green-600 text-white"
                >
                  <Bot className="w-4 h-4 mr-2" />
                  Upload Bot
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Delete Account */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="md:col-span-2"
        >
          <Card className="bg-[var(--dark-card)] border-red-500 bg-red-900/10">
            <CardHeader>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-red-500/20 rounded-lg flex items-center justify-center">
                  <Trash2 className="w-5 h-5 text-red-400" />
                </div>
                <CardTitle className="text-red-400">Excluir Conta</CardTitle>
              </div>
              <CardDescription className="text-red-300">
                ⚠️ AÇÃO IRREVERSÍVEL - Exclui permanentemente sua conta Discord
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert className="bg-red-900/30 border-red-600">
                <AlertTriangle className="h-4 w-4 text-red-500" />
                <AlertDescription className="text-red-200">
                  <strong className="text-red-300">AVISO CRÍTICO:</strong> Esta ação irá excluir permanentemente sua conta Discord. Você perderá:
                  <ul className="list-disc list-inside mt-2 ml-4">
                    <li>Todas as suas mensagens</li>
                    <li>Todos os seus servidores</li>
                    <li>Todas as suas conexões</li>
                    <li>Todo o histórico da conta</li>
                  </ul>
                  <strong>Esta ação NÃO PODE ser desfeita!</strong>
                </AlertDescription>
              </Alert>

              <div className="space-y-3">
                <Input
                  type="password"
                  value={deletePassword}
                  onChange={(e) => setDeletePassword(e.target.value)}
                  placeholder="Digite sua senha para confirmar"
                  className="bg-[var(--dark)] border-red-500 text-white placeholder-red-300"
                />
                <Button
                  onClick={handleDeleteAccount}
                  disabled={isLoading}
                  className="w-full bg-red-600 hover:bg-red-700 text-white"
                >
                  Excluir Conta Permanentemente
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}
import { useState } from "react";
import { motion } from "framer-motion";
import { User, Mail, Lock, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useDiscord } from "@/hooks/use-discord";

export default function AccountSection() {
  const [newUsername, setNewUsername] = useState("");
  const [newEmail, setNewEmail] = useState("");
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  
  const { toast } = useToast();
  const { 
    accountInfo, 
    changeUsername, 
    changeEmail, 
    changePassword,
    updateAvatar,
    isLoading 
  } = useDiscord();

  const handleChangeUsername = () => {
    if (!newUsername.trim() || !currentPassword.trim()) {
      toast({
        title: "Erro",
        description: "Por favor, preencha todos os campos",
        variant: "destructive",
      });
      return;
    }
    changeUsername(newUsername, currentPassword);
  };

  const handleChangeEmail = () => {
    if (!newEmail.trim() || !currentPassword.trim()) {
      toast({
        title: "Erro",
        description: "Por favor, preencha todos os campos",
        variant: "destructive",
      });
      return;
    }
    changeEmail(newEmail, currentPassword);
  };

  const handleChangePassword = () => {
    if (!currentPassword.trim() || !newPassword.trim()) {
      toast({
        title: "Erro",
        description: "Por favor, preencha todos os campos",
        variant: "destructive",
      });
      return;
    }
    changePassword(currentPassword, newPassword);
  };

  const handleUpdateAvatar = () => {
    if (!avatarFile) {
      toast({
        title: "Erro",
        description: "Por favor, selecione uma imagem",
        variant: "destructive",
      });
      return;
    }
    updateAvatar(avatarFile);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setAvatarFile(file);
    }
  };

  return (
    <section className="max-w-4xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold text-white mb-2">📊 Informações da Conta</h1>
        <p className="text-gray-400">Visualize e gerencie as informações da sua conta</p>
      </motion.div>

      {/* Account Info Display */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
        className="mb-6"
      >
        <Card className="bg-[var(--dark-card)] border-[var(--dark-border)]">
          <CardHeader>
            <CardTitle className="text-white">Dados da Conta</CardTitle>
            <CardDescription className="text-gray-400">
              Informações atuais da sua conta Discord
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 bg-gray-700 rounded-full flex items-center justify-center">
                  {accountInfo?.avatar ? (
                    <img 
                      src={accountInfo.avatar} 
                      alt="Avatar" 
                      className="w-full h-full rounded-full object-cover"
                    />
                  ) : (
                    <User className="w-8 h-8 text-gray-400" />
                  )}
                </div>
                <div>
                  <p className="text-gray-400 text-sm">Nome de Usuário</p>
                  <p className="text-white font-medium">
                    {accountInfo?.username || "Carregando..."}
                  </p>
                </div>
              </div>
              <div>
                <p className="text-gray-400 text-sm">ID do Usuário</p>
                <p className="text-white font-medium">
                  {accountInfo?.id || "Carregando..."}
                </p>
              </div>
              <div>
                <p className="text-gray-400 text-sm">Email</p>
                <p className="text-white font-medium">
                  {accountInfo?.email || "Carregando..."}
                </p>
              </div>
              <div>
                <p className="text-gray-400 text-sm">Data de Criação</p>
                <p className="text-white font-medium">
                  {accountInfo?.createdAt || "Carregando..."}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Account Management Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Change Username */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <Card className="bg-[var(--dark-card)] border-[var(--dark-border)]">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <User className="w-5 h-5 text-[var(--primary)]" />
                <span>Alterar Nome</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Input
                value={newUsername}
                onChange={(e) => setNewUsername(e.target.value)}
                placeholder="Novo nome de usuário"
                className="bg-[var(--dark)] border-[var(--dark-border)] text-white placeholder-gray-500"
              />
              <Input
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                placeholder="Senha atual"
                className="bg-[var(--dark)] border-[var(--dark-border)] text-white placeholder-gray-500"
              />
              <Button
                onClick={handleChangeUsername}
                disabled={isLoading}
                className="w-full bg-[var(--primary)] hover:bg-[var(--primary)]/80 text-white"
              >
                Atualizar Nome
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        {/* Change Email */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          <Card className="bg-[var(--dark-card)] border-[var(--dark-border)]">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <Mail className="w-5 h-5 text-[var(--secondary)]" />
                <span>Alterar Email</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Input
                type="email"
                value={newEmail}
                onChange={(e) => setNewEmail(e.target.value)}
                placeholder="Novo email"
                className="bg-[var(--dark)] border-[var(--dark-border)] text-white placeholder-gray-500"
              />
              <Input
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                placeholder="Senha atual"
                className="bg-[var(--dark)] border-[var(--dark-border)] text-white placeholder-gray-500"
              />
              <Button
                onClick={handleChangeEmail}
                disabled={isLoading}
                className="w-full bg-[var(--secondary)] hover:bg-[var(--secondary)]/80 text-white"
              >
                Atualizar Email
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        {/* Change Password */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
        >
          <Card className="bg-[var(--dark-card)] border-[var(--dark-border)]">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <Lock className="w-5 h-5 text-[var(--accent)]" />
                <span>Alterar Senha</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Input
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                placeholder="Senha atual"
                className="bg-[var(--dark)] border-[var(--dark-border)] text-white placeholder-gray-500"
              />
              <Input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Nova senha"
                className="bg-[var(--dark)] border-[var(--dark-border)] text-white placeholder-gray-500"
              />
              <Button
                onClick={handleChangePassword}
                disabled={isLoading}
                className="w-full bg-[var(--accent)] hover:bg-[var(--accent)]/80 text-white"
              >
                Atualizar Senha
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        {/* Avatar Upload */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
        >
          <Card className="bg-[var(--dark-card)] border-[var(--dark-border)]">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <Upload className="w-5 h-5 text-purple-400" />
                <span>Alterar Avatar</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="border-2 border-dashed border-[var(--dark-border)] rounded-lg p-6 text-center">
                <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                <p className="text-gray-400 text-sm mb-2">
                  {avatarFile ? avatarFile.name : "Clique ou arraste uma imagem"}
                </p>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileChange}
                  className="hidden"
                  id="avatar-upload"
                />
                <Label
                  htmlFor="avatar-upload"
                  className="cursor-pointer text-[var(--primary)] hover:text-[var(--primary)]/80"
                >
                  Selecionar Arquivo
                </Label>
              </div>
              <Button
                onClick={handleUpdateAvatar}
                disabled={isLoading}
                className="w-full bg-purple-500 hover:bg-purple-600 text-white"
              >
                Atualizar Avatar
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}

import { useState } from "react";
import { motion } from "framer-motion";
import { Eye, EyeOff, CheckCircle, XCircle, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { useDiscord } from "@/hooks/use-discord";

export default function TokenSection() {
  const [token, setToken] = useState("");
  const [showToken, setShowToken] = useState(false);
  const { toast } = useToast();
  const { validateToken, isValidating, tokenStatus } = useDiscord();

  const handleValidateToken = async () => {
    if (!token.trim()) {
      toast({
        title: "Erro",
        description: "Por favor, insira um token",
        variant: "destructive",
      });
      return;
    }

    try {
      await validateToken(token);
    } catch (error) {
      // Error handling is done in the hook
    }
  };

  const toggleTokenVisibility = () => {
    setShowToken(!showToken);
  };

  return (
    <section className="max-w-4xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold text-white mb-2">🔐 Token do Discord</h1>
        <p className="text-gray-400">Insira seu token do Discord para acessar as ferramentas</p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
      >
        <Card className="bg-[var(--dark-card)] border-[var(--dark-border)]">
          <CardHeader>
            <CardTitle className="text-white">Token do Discord</CardTitle>
            <CardDescription className="text-gray-400">
              Insira seu token para validar e acessar as funcionalidades
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="discord-token" className="text-gray-300">
                Token do Discord
              </Label>
              <div className="relative">
                <Input
                  id="discord-token"
                  type={showToken ? "text" : "password"}
                  value={token}
                  onChange={(e) => setToken(e.target.value)}
                  placeholder="Insira seu token aqui..."
                  className="bg-[var(--dark)] border-[var(--dark-border)] text-white placeholder-gray-500 pr-12"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white"
                  onClick={toggleTokenVisibility}
                >
                  {showToken ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <Button
                onClick={handleValidateToken}
                disabled={isValidating || !token.trim()}
                className="bg-[var(--primary)] hover:bg-[var(--primary)]/80 text-white"
              >
                {isValidating ? "Validando..." : "Validar Token"}
              </Button>
              
              {tokenStatus && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="flex items-center space-x-2"
                >
                  {tokenStatus === "valid" ? (
                    <>
                      <CheckCircle className="h-5 w-5 text-[var(--accent)]" />
                      <span className="text-[var(--accent)] font-medium">Token válido</span>
                    </>
                  ) : (
                    <>
                      <XCircle className="h-5 w-5 text-[var(--destructive)]" />
                      <span className="text-[var(--destructive)] font-medium">Token inválido ou expirado</span>
                    </>
                  )}
                </motion.div>
              )}
            </div>

            <Alert className="bg-yellow-900/30 border-yellow-600">
              <AlertTriangle className="h-4 w-4 text-yellow-500" />
              <AlertDescription className="text-yellow-200">
                <strong className="text-yellow-300">Aviso de Segurança:</strong> Use esta ferramenta por sua própria conta e risco. Tokens são informações sensíveis.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>
      </motion.div>
    </section>
  );
}

import { useState } from "react";
import { motion } from "framer-motion";
import { Trash2, MessageSquare, UserMinus, Star, Info, Bell, Activity } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useDiscord } from "@/hooks/use-discord";

export default function FunctionsSection() {
  const [serverId, setServerId] = useState("");
  const [statusText, setStatusText] = useState("");
  const [statusType, setStatusType] = useState("online");
  const [activityType, setActivityType] = useState("0");
  const { toast } = useToast();
  const { 
    deleteDMs, 
    deleteServerMessages, 
    removeAllFriends,
    checkNitro,
    getAccountInfo,
    clearNotifications,
    updateStatus,
    isLoading 
  } = useDiscord();

  const functionCards = [
    {
      title: "Excluir DMs",
      description: "Apaga todas as mensagens diretas com todos os usuários",
      icon: Trash2,
      color: "bg-red-500/20 text-red-400",
      buttonColor: "bg-red-500 hover:bg-red-600",
      action: () => deleteDMs(),
    },
    {
      title: "Remover Amigos",
      description: "Remove amigos e fecha conversas DM",
      icon: UserMinus,
      color: "bg-purple-500/20 text-purple-400",
      buttonColor: "bg-purple-500 hover:bg-purple-600",
      action: () => removeAllFriends(),
    },
    {
      title: "Verificar Nitro",
      description: "Verifica se a conta possui Nitro e qual o tipo",
      icon: Star,
      color: "bg-[var(--secondary)]/20 text-[var(--secondary)]",
      buttonColor: "bg-[var(--secondary)] hover:bg-[var(--secondary)]/80",
      action: () => checkNitro(),
    },
    {
      title: "Info da Conta",
      description: "Exibe informações detalhadas da sua conta",
      icon: Info,
      color: "bg-[var(--accent)]/20 text-[var(--accent)]",
      buttonColor: "bg-[var(--accent)] hover:bg-[var(--accent)]/80",
      action: () => getAccountInfo(),
    },
    {
      title: "Limpar Notificações",
      description: "Marca todas as notificações como lidas",
      icon: Bell,
      color: "bg-blue-500/20 text-blue-400",
      buttonColor: "bg-blue-500 hover:bg-blue-600",
      action: () => clearNotifications(),
    },
  ];

  const handleDeleteServerMessages = () => {
    if (!serverId.trim()) {
      toast({
        title: "Erro",
        description: "Por favor, insira o ID do servidor",
        variant: "destructive",
      });
      return;
    }
    deleteServerMessages(serverId);
  };

  const handleUpdateStatus = () => {
    if (!statusText.trim()) {
      toast({
        title: "Erro",
        description: "Por favor, insira um texto para o status",
        variant: "destructive",
      });
      return;
    }
    updateStatus(statusText, statusType, activityType);
  };

  return (
    <section className="max-w-6xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold text-white mb-2">⚙️ Funções Principais</h1>
        <p className="text-gray-400">Ferramentas para gerenciar sua conta do Discord</p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {functionCards.map((card, index) => (
          <motion.div
            key={card.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
          >
            <Card className="bg-[var(--dark-card)] border-[var(--dark-border)] hover:border-[var(--primary)] transition-colors duration-200">
              <CardHeader>
                <div className="flex items-center space-x-3 mb-4">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${card.color}`}>
                    <card.icon className="w-5 h-5" />
                  </div>
                  <CardTitle className="text-white">{card.title}</CardTitle>
                </div>
                <CardDescription className="text-gray-400">{card.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <Button
                  onClick={card.action}
                  disabled={isLoading}
                  className={`w-full ${card.buttonColor} text-white`}
                >
                  {card.title}
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        ))}

        {/* Delete Server Messages */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
        >
          <Card className="bg-[var(--dark-card)] border-[var(--dark-border)] hover:border-[var(--primary)] transition-colors duration-200">
            <CardHeader>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-orange-500/20 rounded-lg flex items-center justify-center">
                  <MessageSquare className="w-5 h-5 text-orange-400" />
                </div>
                <CardTitle className="text-white">Apagar Mensagens</CardTitle>
              </div>
              <CardDescription className="text-gray-400">
                Remove todas as suas mensagens em um servidor específico
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <Input
                value={serverId}
                onChange={(e) => setServerId(e.target.value)}
                placeholder="ID do servidor"
                className="bg-[var(--dark)] border-[var(--dark-border)] text-white placeholder-gray-500"
              />
              <Button
                onClick={handleDeleteServerMessages}
                disabled={isLoading}
                className="w-full bg-orange-500 hover:bg-orange-600 text-white"
              >
                Apagar minhas mensagens
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Status Update Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.6 }}
      >
        <Card className="bg-[var(--dark-card)] border-[var(--dark-border)]">
          <CardHeader>
            <CardTitle className="text-white flex items-center space-x-2">
              <Activity className="w-5 h-5 text-[var(--primary)]" />
              <span>Mudar Status</span>
            </CardTitle>
            <CardDescription className="text-gray-400">
              Atualize seu status personalizado no Discord (limitado para self-bots)
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="status-text" className="text-gray-300">
                  Texto do Status
                </Label>
                <Input
                  id="status-text"
                  value={statusText}
                  onChange={(e) => setStatusText(e.target.value)}
                  placeholder="Ex: Jogando Valorant"
                  className="bg-[var(--dark)] border-[var(--dark-border)] text-white placeholder-gray-500"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="status-type" className="text-gray-300">
                  Tipo de Status
                </Label>
                <Select value={statusType} onValueChange={setStatusType}>
                  <SelectTrigger className="bg-[var(--dark)] border-[var(--dark-border)] text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="online">Online</SelectItem>
                    <SelectItem value="idle">Ausente</SelectItem>
                    <SelectItem value="dnd">Não Perturbe</SelectItem>
                    <SelectItem value="invisible">Invisível</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="activity-type" className="text-gray-300">
                  Tipo de Atividade
                </Label>
                <Select value={activityType} onValueChange={setActivityType}>
                  <SelectTrigger className="bg-[var(--dark)] border-[var(--dark-border)] text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0">Jogando</SelectItem>
                    <SelectItem value="1">Transmitindo</SelectItem>
                    <SelectItem value="2">Ouvindo</SelectItem>
                    <SelectItem value="3">Assistindo</SelectItem>
                    <SelectItem value="5">Competindo</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-end">
                <Button
                  onClick={handleUpdateStatus}
                  disabled={isLoading}
                  className="w-full bg-[var(--primary)] hover:bg-[var(--primary)]/80 text-white"
                >
                  Atualizar Status
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </section>
  );
}

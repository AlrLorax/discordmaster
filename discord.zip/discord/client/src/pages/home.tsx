import { useState } from "react";
import Sidebar from "@/components/sidebar";
import TokenSection from "@/components/token-section";
import FunctionsSection from "@/components/functions-section";
import AccountSection from "@/components/account-section";
import ExtrasSection from "@/components/extras-section";

type ActiveSection = "token" | "functions" | "account" | "extras";

export default function Home() {
  const [activeSection, setActiveSection] = useState<ActiveSection>("token");

  const renderActiveSection = () => {
    switch (activeSection) {
      case "token":
        return <TokenSection />;
      case "functions":
        return <FunctionsSection />;
      case "account":
        return <AccountSection />;
      case "extras":
        return <ExtrasSection />;
      default:
        return <TokenSection />;
    }
  };

  return (
    <div className="flex min-h-screen bg-[var(--dark)] text-white">
      <Sidebar activeSection={activeSection} setActiveSection={setActiveSection} />
      <main className="flex-1 ml-20 lg:ml-64 custom-scrollbar">
        <div className="p-4 lg:p-8 animate-fade-in">
          {renderActiveSection()}
        </div>
      </main>
    </div>
  );
}

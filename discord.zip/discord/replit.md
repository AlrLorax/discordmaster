# Discord Tools Application

## Overview

This is a full-stack Discord automation tool built with React (frontend) and Express.js (backend). The application provides a web interface for managing Discord accounts, allowing users to perform various Discord-related operations through a clean, shadcn/ui-based dashboard.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite with ESBuild for production builds
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom Discord-themed dark mode
- **State Management**: React Query (@tanstack/react-query) for server state
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (@neondatabase/serverless)
- **File Uploads**: Multer for handling multipart/form-data
- **Session Management**: PostgreSQL session store with connect-pg-simple
- **API Integration**: Discord API v10 for account operations

### Development Environment
- **Development Server**: Vite dev server with HMR
- **Build Process**: Vite for frontend, ESBuild for backend bundling
- **Type Checking**: TypeScript with strict mode enabled
- **Replit Integration**: Custom plugins for development environment

## Key Components

### Database Schema
- **users**: Basic user authentication (id, username, password)
- **discord_sessions**: Discord token storage and user session management
- **Migration System**: Drizzle Kit for database schema management

### Frontend Components
- **Sidebar Navigation**: Four main sections (Token, Functions, Account, Extras)
- **Token Section**: Discord token validation and management
- **Functions Section**: Discord automation features (delete DMs, remove friends, etc.)
- **Account Section**: Discord account management (username, email, password changes)
- **Extras Section**: Advanced features (banner updates, server management, account deletion)

### Backend Services
- **Storage Layer**: Abstracted storage interface with in-memory implementation
- **Discord API Client**: Direct integration with Discord's REST API
- **Route Handlers**: RESTful endpoints for all Discord operations
- **File Upload Handling**: Support for avatar and banner image uploads

## Data Flow

1. **Authentication Flow**: Users authenticate with Discord tokens stored in session
2. **Token Validation**: Backend validates Discord tokens against Discord API
3. **Account Operations**: Frontend sends requests to backend, which proxies to Discord API
4. **State Management**: React Query manages server state with caching and synchronization
5. **Real-time Updates**: Toast notifications provide user feedback for operations

## External Dependencies

### Core Dependencies
- **Discord API**: Primary integration for all Discord-related operations
- **Neon Database**: Serverless PostgreSQL database hosting
- **Radix UI**: Accessible component primitives for UI
- **Tailwind CSS**: Utility-first CSS framework

### Development Dependencies
- **Vite**: Fast build tool with HMR support
- **TypeScript**: Static type checking
- **Drizzle Kit**: Database migration and schema management
- **Replit Plugins**: Development environment integration

## Deployment Strategy

### Build Process
1. **Frontend Build**: Vite builds React app to `dist/public`
2. **Backend Build**: ESBuild bundles Express server to `dist/index.js`
3. **Database Setup**: Drizzle migrations run against PostgreSQL database

### Environment Configuration
- **Development**: Uses Vite dev server with Express backend
- **Production**: Serves static files from Express with built frontend
- **Database**: Requires `DATABASE_URL` environment variable for PostgreSQL connection

### Hosting Requirements
- Node.js runtime environment
- PostgreSQL database (Neon recommended)
- Environment variables for database connection
- Static file serving capability

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

- **July 08, 2025**: Initial setup completed
- **July 08, 2025**: Fixed Discord API authentication issues
  - Corrected token authorization format (removed "Bot" prefix)
  - Fixed BigInt TypeScript compilation errors
  - Resolved session management issues
  - Fixed CSS import order warning
  - Application now properly validates Discord tokens and makes API calls
- **July 08, 2025**: Improved Discord functions
  - Fixed "Remove Friends" function with better DM channel processing
  - Enhanced "Update Status" function with multiple endpoint fallbacks
  - Added proper error handling for self-bot limitations
  - Improved user feedback messages
- **July 08, 2025**: Added database and new features
  - Migrated from MemStorage to PostgreSQL database with Drizzle ORM
  - Added voice call functionality (join/leave voice channels with duration control)
  - Added bot hosting system for keeping Discord bots online
  - Created new database tables: voice_calls, bot_hosting
  - Enhanced extras section with voice call and bot hosting UI

## Changelog

Changelog:
- July 08, 2025. Initial setup
- July 08, 2025. Fixed API authentication and token validation
CREATE TABLE `bot_hosting` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`session_id` text NOT NULL,
	`bot_token` text NOT NULL,
	`bot_name` text NOT NULL,
	`status` text DEFAULT 'offline' NOT NULL,
	`guild_id` text,
	`start_time` integer,
	`created_at` integer DEFAULT '"2025-07-09T15:06:27.007Z"',
	`updated_at` integer DEFAULT '"2025-07-09T15:06:27.007Z"'
);
--> statement-breakpoint
CREATE TABLE `discord_sessions` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`session_id` text NOT NULL,
	`discord_token` text NOT NULL,
	`user_id` text NOT NULL,
	`username` text NOT NULL,
	`email` text,
	`avatar` text,
	`created_at` integer DEFAULT '"2025-07-09T15:06:27.006Z"',
	`updated_at` integer DEFAULT '"2025-07-09T15:06:27.006Z"'
);
--> statement-breakpoint
CREATE UNIQUE INDEX `discord_sessions_session_id_unique` ON `discord_sessions` (`session_id`);--> statement-breakpoint
CREATE TABLE `users` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`username` text NOT NULL,
	`password` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `users_username_unique` ON `users` (`username`);--> statement-breakpoint
CREATE TABLE `voice_calls` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`session_id` text NOT NULL,
	`channel_id` text NOT NULL,
	`guild_id` text,
	`duration` integer,
	`start_time` integer DEFAULT '"2025-07-09T15:06:27.006Z"',
	`end_time` integer,
	`status` text DEFAULT 'active' NOT NULL,
	`created_at` integer DEFAULT '"2025-07-09T15:06:27.006Z"'
);
